import { Box } from "@mui/material";
import People from "../components/people";

function StaffDirectoryPage() {
    return (
        <Box>
            <People />
        </Box>
    )
}

export default StaffDirectoryPage;