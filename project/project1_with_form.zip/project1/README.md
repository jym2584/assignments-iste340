# This project is ran using a CORS Proxy
Look at the `aws_proxy` directory.