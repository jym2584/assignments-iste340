import { Box } from "@mui/material";
import Courses from "../components/courses";

function CoursesPage() {
    return (
        <Box>
            <Courses/>
        </Box>
    )
}

export default CoursesPage;